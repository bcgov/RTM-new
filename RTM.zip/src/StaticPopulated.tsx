import React from 'react';
import { Header } from './components/Header';
import { Sidebar } from './components/Sidebar';
import { DataTable } from './components/DataTable';
import { Upload, Download } from 'lucide-react';

// Sample data based on the Excel screenshot
const sampleData = [
  { GRADE: 'B', BALSAM: '', HEMLOCK: '', CEDAR: '', CYPRESS: '', FIR: '448.74', SPRUCE: '', 'PINE**': '' },
  { GRADE: 'C', BALSAM: '', HEMLOCK: '', CEDAR: '', CYPRESS: '', FIR: '195.30', SPRUCE: '', 'PINE**': '' },
  { GRADE: 'D', BALSAM: '347.92', HEMLOCK: '542.27', CEDAR: '900.89', CYPRESS: '567.08', FIR: '776.16', SPRUCE: '453.87', 'PINE**': '76.38' },
  { GRADE: 'E', BALSAM: '', HEMLOCK: '', CEDAR: '', CYPRESS: '', FIR: '', SPRUCE: '453.87', 'PINE**': '' },
  { GRADE: 'F', BALSAM: '262.56', HEMLOCK: '427.01', CEDAR: '813.14', CYPRESS: '465.20', FIR: '624.40', SPRUCE: '453.87', 'PINE**': '76.38' },
  { GRADE: 'G', BALSAM: '', HEMLOCK: '', CEDAR: '', CYPRESS: '', FIR: '', SPRUCE: '453.87', 'PINE**': '' },
  { GRADE: 'H', BALSAM: '145.04', HEMLOCK: '122.11', CEDAR: '572.48', CYPRESS: '325.77', FIR: '211.78', SPRUCE: '98.58', 'PINE**': '76.38' },
  { GRADE: 'I', BALSAM: '163.69', HEMLOCK: '108.51', CEDAR: '359.12', CYPRESS: '234.75', FIR: '176.08', SPRUCE: '71.11', 'PINE**': '60.01' },
  { GRADE: 'J', BALSAM: '79.86', HEMLOCK: '90.22', CEDAR: '261.10', CYPRESS: '89.33', FIR: '119.30', SPRUCE: '74.10', 'PINE**': '77.45' },
  { GRADE: 'K', BALSAM: '', HEMLOCK: '', CEDAR: '655.65', CYPRESS: '', FIR: '', SPRUCE: '', 'PINE**': '' },
  { GRADE: 'L', BALSAM: '', HEMLOCK: '', CEDAR: '491.52', CYPRESS: '', FIR: '', SPRUCE: '', 'PINE**': '' },
  { GRADE: 'M', BALSAM: '', HEMLOCK: '', CEDAR: '332.85', CYPRESS: '', FIR: '', SPRUCE: '', 'PINE**': '' },
  { GRADE: 'N', BALSAM: '58.36', HEMLOCK: '59.09', CEDAR: '133.49', CYPRESS: '166.40', FIR: '80.70', SPRUCE: '40.38', 'PINE**': '55.14' },
  { GRADE: 'X', BALSAM: '57.49', HEMLOCK: '54.51', CEDAR: '100.08', CYPRESS: '124.57', FIR: '48.16', SPRUCE: '45.49', 'PINE**': '45.16' },
  { GRADE: 'Y', BALSAM: '51.74', HEMLOCK: '23.84', CEDAR: '28.50', CYPRESS: '28.06', FIR: '38.37', SPRUCE: '31.61', 'PINE**': '19.81' },
  { GRADE: 'Z', BALSAM: '77.47', HEMLOCK: '84.04', CEDAR: '301.38', CYPRESS: '178.32', FIR: '126.08', SPRUCE: '75.91', 'PINE**': '72.53' },
];

const sampleColumns = ['GRADE', 'BALSAM', 'HEMLOCK', 'CEDAR', 'CYPRESS', 'FIR', 'SPRUCE', 'PINE**'];

export default function StaticPopulated() {
  return (
    <div className="min-h-screen bg-[#f4f4f4] flex flex-col">
      <Header />
      
      <div className="flex flex-1">
        <Sidebar />
        
        <main className="flex-1 p-8">
          <div className="max-w-[1600px] mx-auto">
            <h1 className="mb-6">Data Upload</h1>
            
            <div className="space-y-6">
              {/* Upload Section */}
              <div className="bg-white border border-[#e0e0e0]">
                <div className="p-4 border-b border-[#e0e0e0] flex items-center justify-between">
                  <div>
                    <h2 className="mb-1">Upload Excel Spreadsheet</h2>
                    <p className="text-sm text-[#525252]">
                      Select or drag and drop your file to upload
                    </p>
                  </div>
                  <button
                    className="flex items-center gap-2 px-4 py-2 border border-[#0f62fe] text-[#0f62fe] hover:bg-[#e8f0ff] transition-colors"
                  >
                    <Download size={16} />
                    <span>Download Template</span>
                  </button>
                </div>
                <div className="p-6 border-2 border-dashed border-[#e0e0e0] m-4 bg-[#f4f4f4]">
                  <div className="flex items-center gap-4">
                    <div className="w-12 h-12 bg-[#e0e0e0] rounded-full flex items-center justify-center flex-shrink-0">
                      <Upload size={24} className="text-[#525252]" />
                    </div>
                    <div className="flex-1">
                      <p className="text-sm text-[#161616] mb-1">
                        Drag and drop your Excel file here, or
                      </p>
                      <p className="text-xs text-[#525252]">
                        Supported formats: .xlsx, .xls
                      </p>
                    </div>
                    <button
                      className="bg-[#0f62fe] text-white px-4 py-2 hover:bg-[#0353e9] transition-colors flex-shrink-0"
                    >
                      Browse files
                    </button>
                  </div>
                </div>
              </div>

              {/* Data Table Section - Populated */}
              <div className="bg-white border border-[#e0e0e0]">
                <div className="p-4 border-b border-[#e0e0e0] flex items-center justify-between">
                  <div>
                    <h2 className="mb-1">Data Preview</h2>
                    <p className="text-sm text-[#525252]">
                      Review the data below and click Save to confirm
                    </p>
                  </div>
                  <div className="flex gap-3">
                    <button
                      className="px-4 py-2 border border-[#e0e0e0] text-[#161616] hover:bg-[#e0e0e0] transition-colors"
                    >
                      Clear
                    </button>
                    <button
                      className="bg-[#0f62fe] text-white px-6 py-2 hover:bg-[#0353e9] transition-colors"
                    >
                      Save
                    </button>
                  </div>
                </div>
                
                <DataTable data={sampleData} columns={sampleColumns} />
              </div>
            </div>
            
            {/* Submit Button at Bottom */}
            <div className="mt-6 flex justify-end">
              <button
                className="bg-[#0f62fe] text-white px-8 py-3 hover:bg-[#0353e9] transition-colors"
              >
                Submit
              </button>
            </div>
          </div>
        </main>
      </div>
    </div>
  );
}
