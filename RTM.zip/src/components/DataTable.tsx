import React from 'react';

interface DataTableProps {
  data: any[];
  columns: string[];
}

export function DataTable({ data, columns }: DataTableProps) {
  // If columns are not properly set, don't render
  if (!columns || columns.length === 0) {
    return <div className="p-12 text-center text-[#525252]">Loading...</div>;
  }

  // Filter out Average and Grand Total Average rows from data if they exist
  const filteredData = data.filter(row => {
    const gradeValue = row['GRADE'] || row['Grade'] || row['grade'];
    return gradeValue !== 'Average' && gradeValue !== 'Grand Total Average';
  });

  // Ensure GRADE column is always present and first
  const orderedColumns = columns.includes('GRADE') 
    ? ['GRADE', ...columns.filter(col => col !== 'GRADE')]
    : columns;

  // Calculate averages for numeric columns
  const calculateAverage = (columnName: string) => {
    if (columnName === 'GRADE') return '';
    
    const values = filteredData
      .map(row => row[columnName])
      .filter(val => val !== null && val !== undefined && val !== '' && !isNaN(Number(val)))
      .map(val => Number(val));
    
    if (values.length === 0) return '-';
    
    const sum = values.reduce((acc, val) => acc + val, 0);
    const avg = sum / values.length;
    return avg.toFixed(2);
  };

  // Calculate grand total average (average of all numeric values in the row)
  const calculateGrandTotalAverage = () => {
    const allValues: number[] = [];
    
    orderedColumns.forEach(column => {
      if (column !== 'GRADE') {
        filteredData.forEach(row => {
          const val = row[column];
          if (val !== null && val !== undefined && val !== '' && !isNaN(Number(val))) {
            allValues.push(Number(val));
          }
        });
      }
    });
    
    if (allValues.length === 0) return '-';
    
    const sum = allValues.reduce((acc, val) => acc + val, 0);
    const avg = sum / allValues.length;
    return avg.toFixed(2);
  };

  const grandTotalAvg = calculateGrandTotalAverage();

  return (
    <div className="overflow-auto">
      <table className="w-full">
        <thead className="bg-[#e0e0e0] border-b border-[#c6c6c6]">
          <tr>
            {orderedColumns.map((column) => (
              <th 
                key={column}
                className={`px-4 py-3 text-left text-xs text-[#161616] border-b border-[#c6c6c6] ${column === 'GRADE' ? 'w-20' : ''}`}
              >
                {column}
              </th>
            ))}
          </tr>
        </thead>
        <tbody>
          {filteredData.map((row, index) => (
            <tr 
              key={index}
              className="border-b border-[#e0e0e0] hover:bg-[#f4f4f4] transition-colors"
            >
              {orderedColumns.map((column) => (
                <td 
                  key={`${index}-${column}`}
                  className={`px-4 py-3 text-sm text-[#161616] ${column === 'GRADE' ? 'w-20' : ''}`}
                >
                  {row[column] !== null && row[column] !== undefined 
                    ? String(row[column]) 
                    : '-'}
                </td>
              ))}
            </tr>
          ))}
          
          {/* Average Row */}
          <tr className="bg-[#e0e0e0] border-t-2 border-[#c6c6c6]">
            {orderedColumns.map((column) => (
              <td 
                key={`avg-${column}`}
                className={`px-4 py-3 text-sm text-[#161616] ${column === 'GRADE' ? 'w-20' : ''}`}
              >
                {column === 'GRADE' ? 'Average' : calculateAverage(column)}
              </td>
            ))}
          </tr>
          
          {/* Grand Total Average Row */}
          <tr className="bg-[#e0e0e0] border-t border-[#c6c6c6]">
            {orderedColumns.map((column) => (
              <td 
                key={`grandtotal-${column}`}
                className={`px-4 py-3 text-sm text-[#161616] ${column === 'GRADE' ? 'w-20' : ''}`}
              >
                {column === 'GRADE' ? 'Grand Total Average' : grandTotalAvg}
              </td>
            ))}
          </tr>
        </tbody>
      </table>
      
      <div className="px-4 py-3 bg-white border-t border-[#e0e0e0] flex items-center justify-between text-sm text-[#525252]">
        <div>
          Total rows: {filteredData.length}
        </div>
        <div>
          1 - {filteredData.length} of {filteredData.length} items
        </div>
      </div>
    </div>
  );
}
