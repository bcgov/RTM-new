import React from 'react';
import { LayoutDashboard, HelpCircle } from 'lucide-react';

export function Sidebar() {
  return (
    <aside className="w-[200px] bg-[#f4f4f4] border-r border-[#e0e0e0] flex flex-col">
      <nav className="flex-1 py-4">
        <div className="mb-6">
          <a 
            href="#" 
            className="flex items-center gap-3 px-4 py-2 text-[#161616] bg-[#e0e0e0] border-l-3 border-[#0f62fe]"
          >
            <LayoutDashboard size={16} />
            <span className="text-sm">Dashboard</span>
          </a>
        </div>
      </nav>
      
      <div className="border-t border-[#e0e0e0] p-4">
        <div className="text-xs text-[#525252] mb-2">Support</div>
        <a 
          href="#" 
          className="flex items-center gap-2 text-[#0f62fe] hover:underline text-sm"
        >
          <HelpCircle size={16} />
          <span>Need help?</span>
        </a>
      </div>
    </aside>
  );
}
