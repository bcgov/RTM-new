import React, { useRef } from 'react';
import { Upload, Download } from 'lucide-react';
import * as XLSX from 'xlsx';
import { DataTable } from './DataTable';

interface FileUploadSectionProps {
  onDataUploaded: (data: any[], columns: string[]) => void;
  uploadedData: any[];
  columns: string[];
  onSave: () => void;
}

export function FileUploadSection({ 
  onDataUploaded, 
  uploadedData, 
  columns,
  onSave 
}: FileUploadSectionProps) {
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleDownloadTemplate = () => {
    // Create template data matching the screenshot exactly
    const grades = ['B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'U', 'X', 'Y'];
    const templateData = grades.map(grade => ({
      GRADE: grade,
      BALSAM: '',
      HEMLOCK: '',
      CEDAR: '',
      CYPRESS: '',
      FIR: '',
      SPRUCE: '',
      'PINE**': ''
    }));

    // Add Average and Grand Total Average rows
    templateData.push(
      { GRADE: 'Average', BALSAM: '', HEMLOCK: '', CEDAR: '', CYPRESS: '', FIR: '', SPRUCE: '', 'PINE**': '' },
      { GRADE: 'Grand Total Average', BALSAM: '', HEMLOCK: '', CEDAR: '', CYPRESS: '', FIR: '', SPRUCE: '', 'PINE**': '' }
    );

    // Create worksheet from template data
    const worksheet = XLSX.utils.json_to_sheet(templateData);
    const workbook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(workbook, worksheet, 'Template');

    // Download the file
    XLSX.writeFile(workbook, 'data_upload_template.xlsx');
  };

  const handleFileUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (e) => {
      try {
        const data = e.target?.result;
        const workbook = XLSX.read(data, { type: 'binary' });
        const sheetName = workbook.SheetNames[0];
        const worksheet = workbook.Sheets[sheetName];
        const json = XLSX.utils.sheet_to_json(worksheet);
        
        if (json.length > 0) {
          const cols = Object.keys(json[0] as object);
          onDataUploaded(json, cols);
        }
      } catch (error) {
        console.error('Error parsing file:', error);
        alert('Error parsing Excel file. Please make sure it\'s a valid Excel file.');
      }
    };
    reader.readAsBinaryString(file);
  };

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    
    const file = e.dataTransfer.files?.[0];
    if (file && (file.name.endsWith('.xlsx') || file.name.endsWith('.xls'))) {
      const fakeEvent = {
        target: {
          files: [file]
        }
      } as any;
      handleFileUpload(fakeEvent);
    } else {
      alert('Please upload a valid Excel file (.xlsx or .xls)');
    }
  };

  return (
    <div className="space-y-6">
      {/* Upload Section - Always Visible */}
      <div className="bg-white border border-[#e0e0e0]">
        <div className="p-4 border-b border-[#e0e0e0] flex items-center justify-between">
          <div>
            <h2 className="mb-1">Upload Excel Spreadsheet</h2>
            <p className="text-sm text-[#525252]">
              Select or drag and drop your file to upload
            </p>
          </div>
          <button
            onClick={handleDownloadTemplate}
            className="flex items-center gap-2 px-4 py-2 border border-[#0f62fe] text-[#0f62fe] hover:bg-[#e8f0ff] transition-colors"
          >
            <Download size={16} />
            <span>Download Template</span>
          </button>
        </div>
        <div 
          className="p-6 border-2 border-dashed border-[#e0e0e0] m-4 bg-[#f4f4f4]"
          onDragOver={handleDragOver}
          onDrop={handleDrop}
        >
          <div className="flex items-center gap-4">
            <div className="w-12 h-12 bg-[#e0e0e0] rounded-full flex items-center justify-center flex-shrink-0">
              <Upload size={24} className="text-[#525252]" />
            </div>
            <div className="flex-1">
              <p className="text-sm text-[#161616] mb-1">
                Drag and drop your Excel file here, or
              </p>
              <p className="text-xs text-[#525252]">
                Supported formats: .xlsx, .xls
              </p>
            </div>
            <input
              ref={fileInputRef}
              type="file"
              accept=".xlsx,.xls"
              onChange={handleFileUpload}
              className="hidden"
            />
            <button
              onClick={() => fileInputRef.current?.click()}
              className="bg-[#0f62fe] text-white px-4 py-2 hover:bg-[#0353e9] transition-colors flex-shrink-0"
            >
              Browse files
            </button>
          </div>
        </div>
      </div>

      {/* Data Table Section - Always Visible */}
      <div className="bg-white border border-[#e0e0e0]">
        <div className="p-4 border-b border-[#e0e0e0] flex items-center justify-between">
          <div>
            <h2 className="mb-1">Data Preview</h2>
            <p className="text-sm text-[#525252]">
              {uploadedData.length > 0 
                ? 'Review the data below and click Save to confirm' 
                : 'Upload a file to view data'}
            </p>
          </div>
          {uploadedData.length > 0 && (
            <div className="flex gap-3">
              <button
                onClick={() => {
                  onDataUploaded([], []);
                  if (fileInputRef.current) {
                    fileInputRef.current.value = '';
                  }
                }}
                className="px-4 py-2 border border-[#e0e0e0] text-[#161616] hover:bg-[#e0e0e0] transition-colors"
              >
                Clear
              </button>
              <button
                onClick={onSave}
                className="bg-[#0f62fe] text-white px-6 py-2 hover:bg-[#0353e9] transition-colors"
              >
                Save
              </button>
            </div>
          )}
        </div>
        
        {uploadedData.length > 0 ? (
          <DataTable data={uploadedData} columns={columns} />
        ) : (
          <div className="p-12 text-center text-[#525252]">
            <div className="flex justify-center mb-4">
              <div className="w-16 h-16 bg-[#e0e0e0] rounded-full flex items-center justify-center">
                <Upload size={32} className="text-[#525252]" />
              </div>
            </div>
            <p>No data uploaded yet</p>
            <p className="text-sm mt-2">Upload an Excel file to see the data here</p>
          </div>
        )}
      </div>
    </div>
  );
}
