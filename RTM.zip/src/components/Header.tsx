import React from 'react';
import { User } from 'lucide-react';

export function Header() {
  return (
    <header className="bg-[#0f62fe] text-white h-12 flex items-center justify-between px-4">
      <h1 className="text-sm">Revenue Table Management</h1>
      <button className="p-2 hover:bg-[#0353e9] rounded">
        <User size={16} />
      </button>
    </header>
  );
}
