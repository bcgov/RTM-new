import React, { useState, useEffect } from 'react';
import { Header } from './components/Header';
import { Sidebar } from './components/Sidebar';
import { FileUploadSection } from './components/FileUploadSection';

// Sample data based on the Excel screenshot
const sampleData = [
  { GRADE: 'B', BALSAM: '', HEMLOCK: '', CEDAR: '', CYPRESS: '', FIR: '448.74', SPRUCE: '', 'PINE**': '' },
  { GRADE: 'C', BALSAM: '', HEMLOCK: '', CEDAR: '', CYPRESS: '', FIR: '195.30', SPRUCE: '', 'PINE**': '' },
  { GRADE: 'D', BALSAM: '347.92', HEMLOCK: '542.27', CEDAR: '900.89', CYPRESS: '567.08', FIR: '776.16', SPRUCE: '453.87', 'PINE**': '76.38' },
  { GRADE: 'E', BALSAM: '', HEMLOCK: '', CEDAR: '', CYPRESS: '', FIR: '', SPRUCE: '453.87', 'PINE**': '' },
  { GRADE: 'F', BALSAM: '262.56', HEMLOCK: '427.01', CEDAR: '813.14', CYPRESS: '465.20', FIR: '624.40', SPRUCE: '453.87', 'PINE**': '76.38' },
  { GRADE: 'G', BALSAM: '', HEMLOCK: '', CEDAR: '', CYPRESS: '', FIR: '', SPRUCE: '453.87', 'PINE**': '' },
  { GRADE: 'H', BALSAM: '145.04', HEMLOCK: '122.11', CEDAR: '572.48', CYPRESS: '325.77', FIR: '211.78', SPRUCE: '98.58', 'PINE**': '76.38' },
  { GRADE: 'I', BALSAM: '163.69', HEMLOCK: '108.51', CEDAR: '359.12', CYPRESS: '234.75', FIR: '176.08', SPRUCE: '71.11', 'PINE**': '60.01' },
  { GRADE: 'J', BALSAM: '79.86', HEMLOCK: '90.22', CEDAR: '261.10', CYPRESS: '89.33', FIR: '119.30', SPRUCE: '74.10', 'PINE**': '77.45' },
  { GRADE: 'K', BALSAM: '', HEMLOCK: '', CEDAR: '655.65', CYPRESS: '', FIR: '', SPRUCE: '', 'PINE**': '' },
  { GRADE: 'L', BALSAM: '', HEMLOCK: '', CEDAR: '491.52', CYPRESS: '', FIR: '', SPRUCE: '', 'PINE**': '' },
  { GRADE: 'M', BALSAM: '', HEMLOCK: '', CEDAR: '332.85', CYPRESS: '', FIR: '', SPRUCE: '', 'PINE**': '' },
  { GRADE: 'N', BALSAM: '58.36', HEMLOCK: '59.09', CEDAR: '133.49', CYPRESS: '166.40', FIR: '80.70', SPRUCE: '40.38', 'PINE**': '55.14' },
  { GRADE: 'X', BALSAM: '57.49', HEMLOCK: '54.51', CEDAR: '100.08', CYPRESS: '124.57', FIR: '48.16', SPRUCE: '45.49', 'PINE**': '45.16' },
  { GRADE: 'Y', BALSAM: '51.74', HEMLOCK: '23.84', CEDAR: '28.50', CYPRESS: '28.06', FIR: '38.37', SPRUCE: '31.61', 'PINE**': '19.81' },
  { GRADE: 'Z', BALSAM: '77.47', HEMLOCK: '84.04', CEDAR: '301.38', CYPRESS: '178.32', FIR: '126.08', SPRUCE: '75.91', 'PINE**': '72.53' },
];

const sampleColumns = ['GRADE', 'BALSAM', 'HEMLOCK', 'CEDAR', 'CYPRESS', 'FIR', 'SPRUCE', 'PINE**'];

// Define expected template columns outside component
const EXPECTED_COLUMNS = ['GRADE', 'BALSAM', 'HEMLOCK', 'CEDAR', 'CYPRESS', 'FIR', 'SPRUCE', 'PINE**'];

export default function App() {
  const [uploadedData, setUploadedData] = useState<any[]>(sampleData);
  const [columns, setColumns] = useState<string[]>(EXPECTED_COLUMNS);
  const [showSuccess, setShowSuccess] = useState(false);
  const [showError, setShowError] = useState(false);
  const [errorMessage, setErrorMessage] = useState('');
  const [isReady, setIsReady] = useState(false);
  
  // Ensure data is ready on mount
  useEffect(() => {
    setUploadedData(sampleData);
    setColumns(EXPECTED_COLUMNS);
    setIsReady(true);
  }, []);

  const handleDataUploaded = (data: any[], cols: string[]) => {
    setUploadedData(data);
    setColumns(cols);
    setShowSuccess(false);
    setShowError(false);
  };

  const validateColumns = () => {
    // Check if columns match the expected template
    if (columns.length !== EXPECTED_COLUMNS.length) {
      return false;
    }
    
    // Check if all expected columns are present
    for (const expectedCol of EXPECTED_COLUMNS) {
      if (!columns.includes(expectedCol)) {
        return false;
      }
    }
    
    return true;
  };
  
  // Don't render until ready
  if (!isReady) {
    return (
      <div className="min-h-screen bg-[#f4f4f4] flex items-center justify-center">
        <div className="text-[#525252]">Loading...</div>
      </div>
    );
  }

  const handleSave = () => {
    // Validate columns before saving
    if (!validateColumns()) {
      const message = 
        'The uploaded file does not match the template format.\n\n' +
        'Please download the template and use the correct format.';
      
      setErrorMessage(message);
      setShowError(true);
      setShowSuccess(false);
      
      return;
    }
    
    // Simulate saving the data
    console.log('Saving data:', uploadedData);
    setShowSuccess(true);
    setShowError(false);
  };

  return (
    <div className="min-h-screen bg-[#f4f4f4] flex flex-col">
      <Header />
      
      <div className="flex flex-1">
        <Sidebar />
        
        <main className="flex-1 p-8">
          <div className="max-w-[1600px] mx-auto">
            <h1 className="mb-6">Data Upload</h1>
            
            {showSuccess && (
              <div className="mb-6 bg-[#24a148] text-white p-4 flex items-start gap-3">
                <svg className="w-5 h-5 mt-0.5 flex-shrink-0" fill="currentColor" viewBox="0 0 16 16">
                  <path d="M8 0C3.6 0 0 3.6 0 8s3.6 8 8 8 8-3.6 8-8-3.6-8-8-8zm3.9 6.2l-4.5 4.5c-.1.1-.3.2-.4.2s-.3-.1-.4-.2l-2.5-2.5c-.2-.2-.2-.5 0-.7s.5-.2.7 0l2.1 2.1 4.1-4.1c.2-.2.5-.2.7 0s.2.5.1.7z"/>
                </svg>
                <div className="flex-1">
                  <div className="font-semibold mb-1">Data uploaded successfully!</div>
                  <div className="text-sm">Your data has been saved to the system.</div>
                </div>
                <button
                  onClick={() => setShowSuccess(false)}
                  className="flex-shrink-0 hover:bg-[#1e8139] p-1 transition-colors"
                  aria-label="Close notification"
                >
                  <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 16 16">
                    <path d="M12 4.7L11.3 4 8 7.3 4.7 4 4 4.7 7.3 8 4 11.3l.7.7L8 8.7l3.3 3.3.7-.7L8.7 8z"/>
                  </svg>
                </button>
              </div>
            )}
            
            {showError && (
              <div className="mb-6 bg-[#da1e28] text-white p-4 flex items-start gap-3">
                <svg className="w-5 h-5 mt-0.5 flex-shrink-0" fill="currentColor" viewBox="0 0 16 16">
                  <path d="M8 0C3.6 0 0 3.6 0 8s3.6 8 8 8 8-3.6 8-8-3.6-8-8-8zm3.5 10.1l-1.4 1.4L8 9.4l-2.1 2.1-1.4-1.4L6.6 8 4.5 5.9l1.4-1.4L8 6.6l2.1-2.1 1.4 1.4L9.4 8l2.1 2.1z"/>
                </svg>
                <div className="flex-1">
                  <div className="font-semibold mb-1">Validation Error</div>
                  <div className="text-sm whitespace-pre-line">{errorMessage}</div>
                </div>
                <button
                  onClick={() => setShowError(false)}
                  className="flex-shrink-0 hover:bg-[#b81921] p-1 transition-colors"
                  aria-label="Close notification"
                >
                  <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 16 16">
                    <path d="M12 4.7L11.3 4 8 7.3 4.7 4 4 4.7 7.3 8 4 11.3l.7.7L8 8.7l3.3 3.3.7-.7L8.7 8z"/>
                  </svg>
                </button>
              </div>
            )}
            
            <FileUploadSection 
              key={columns.join(',')}
              onDataUploaded={handleDataUploaded}
              uploadedData={uploadedData}
              columns={columns}
              onSave={handleSave}
            />
            
            {uploadedData.length > 0 && (
              <div className="mt-6 flex justify-end">
                <button
                  onClick={handleSave}
                  className="bg-[#0f62fe] text-white px-8 py-3 hover:bg-[#0353e9] transition-colors"
                >
                  Submit
                </button>
              </div>
            )}
          </div>
        </main>
      </div>
    </div>
  );
}
